# Predicting Customer Churn with Tabular Data

DATA 4380 group project, Fall 2026, University of Texas at Arlington
Uyen Nguyen, Amukta Chaganty, Prakriti Kattel

We built models to predict which telecom customers are about to leave (churn). We started with the small, clean IBM Telco dataset to get the process right, then applied it to Cell2Cell, a much larger and messier dataset from a real wireless carrier.

Most customers stay, so a model that always says "stayed" is already 71 to 74% accurate. Because of that we judged models by recall, F1, ROC-AUC and PR-AUC instead of accuracy.

## What's in this repo

```
tabular/
  telco_churn.ipynb       IBM Telco: cleaning, baselines, tuning, feature selection, SMOTE, final test
  cell2cell_churn.ipynb   Cell2Cell: EDA, cleaning, baselines, XGBoost, new features, final test
  data/                   the two CSV files
requirements.txt
```

Both notebooks are already run, so the tables and plots show up directly on GitHub.

## How we worked

- **Split first.** We set aside a stratified 20% test set before doing anything else and scored it only once, at the very end.
- **No leakage.** Filling missing values, scaling, one-hot encoding, feature selection and SMOTE all happen inside scikit-learn pipelines. In cross-validation, each fold fits them on its own training rows only.
- **Choices come from 5-fold cross-validation** on the training set.
- **Models:** Dummy, Logistic Regression and Random Forest on both datasets (plus Decision Tree on Cell2Cell), then a tuned XGBoost. We tried class weights, SMOTE, ANOVA feature selection, a tuned decision cutoff, and 13 new features on Cell2Cell.

### Cleaning

- **Telco:** `TotalCharges` is stored as text, and 11 blanks (all new customers with tenure 0) hide in it. Median and mean fills gave the same F1 (0.592), and a product fill was slightly worse (0.580), so we used the median. We merged "No internet service" and "No phone service" into "No" and dropped `customerID`.
- **Cell2Cell:** a lot of the missing data is hidden behind codes like age 0, income group 0 and "Unknown". We treated those as missing (or kept "Unknown" as its own category), filled numbers with the median plus a "was missing" flag, shortened `ServiceArea` to its first 3 characters (747 values down to 57 markets), converted `CreditRating` to 1 to 7, and dropped `CustomerID`.

## Results

| Dataset | Final model | Test ROC-AUC | Test F1 |
|---|---|---|---|
| IBM Telco (7,043 customers, 26.5% churn) | Logistic Regression, class weights, 15 columns, tuned cutoff | 0.832 | 0.607 |
| Cell2Cell (51,047 customers, 28.8% churn) | XGBoost, class weights, 13 new features, cutoff 0.42 | 0.684 | 0.50 |

On Cell2Cell the model catches 80% of churners (recall 0.80) with 0.37 precision, and PR-AUC is 0.464 against 0.288 for random guessing.

The main thing we learned is that tuning, SMOTE, feature selection and feature engineering mostly shifted the balance between recall and precision. They barely changed how well customers were ranked, which stayed near 0.84 ROC-AUC on Telco and 0.68 on Cell2Cell. Cell2Cell also has no market information such as competitor offers, so some of the real drivers of churn are not in the data.

## Running the notebooks

The data comes from Kaggle and is already in `tabular/data/`:

- IBM Telco: https://www.kaggle.com/datasets/blastchar/telco-customer-churn
- Cell2Cell: https://www.kaggle.com/datasets/jpacse/datasets-for-churn-telecom

To run locally:

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
jupyter notebook tabular/
```

Open a notebook and choose Run All. In Google Colab, upload the notebook and its CSV file, then Run All. Cell2Cell is the slow one (the Random Forest baseline alone took about 3 minutes for us). Random seeds are fixed at 42.

## Reference

Omar, A. S., Ogada, K., and Tole, K. (2026). A hybrid feature selection framework for dimensionality-optimized customer churn prediction. *Scientific Reports*, 16, 25758. https://doi.org/10.1038/s41598-026-52160-z
